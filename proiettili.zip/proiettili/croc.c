#include <unistd.h>
#include <ncurses.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>
#include <errno.h>

#include "croc.h"
#include "rana.h"
#include "messaggi.h"

#define CROCLEN 6


void tronca_stringa(char *str)
{
    size_t len = strlen(str);
    if (len > 0)
    {
        str[len - 1] = '\0'; // Sostituisce l'ultimo carattere con il terminatore di stringa
    }
}

int stampa_coccodrillo_mat(int pos_x, int pos_y, bool verso_destra)
{

    const char CROCMATSX[2][6] = {{'>', '=', '=', '=', '=', '-'}, {' ', '\'', ' ', ' ', '\'', ' '}};
    const char CROCMATDX[2][6] = {{'-', '=', '=', '=', '=', '<'}, {' ', '\'', ' ', ' ', '\'', ' '}};

    //char coccodrillo[2][6];
    int dist = 0;

    if (verso_destra)
    {
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < 6; j++)
            {
                
                mvaddch(pos_y + i, pos_x + j, CROCMATDX[i][j]);
                
            }
        }
    }
    else
    {
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < 6; j++)
            {
                //coccodrillo[i][j] = CROCMATSX[i][j];
                mvaddch(pos_y + i, pos_x + j, CROCMATSX[i][j]);
            }
        }
    }
    

    return 0;
}


bool assegna_verso_coccodrillo(int i)
{
    bool verso_destra = false;

    //ASSEGNA IL VERSO DEL COCCODRILLO
    if(i%2)
    {
        verso_destra = true;
    }
    else
    {
        verso_destra = false;
    }

    return verso_destra;
}


void assegna_spawn_x_coccodrillo(bool verso_destra, float * pos_x_croc, int spawn_x_s, int spawn_x_d)
{
    //ASSEGNA LA POSIZIONE X IN BASE AL LATO DI SPAWN
    if(verso_destra)
    {
        *pos_x_croc = spawn_x_s;
    }
    else
    {
        *pos_x_croc = spawn_x_d;
    }
}

void assegna_pos_y_in_base_a_indice_coccodrillo(int i, int * pos_y_croc)
{
    i = i%12;//TRASFORMA INDICE DEI COCCODRILLI NON DEL PRIMO GRUPPO

    //ASSEGNA LA POSIZIONE Y IN BASE ALL'INDICE
    switch (i)
    {
        case 0:
            *pos_y_croc = 10;
            break;

        case 1:
            *pos_y_croc = 12;
            break;

        case 2:
            *pos_y_croc = 14;
            break;

        case 3:
            *pos_y_croc = 16;
            break;

        case 4:
            *pos_y_croc = 18;
            break;

        case 5:
            *pos_y_croc = 20;
            break;

        case 6:
            *pos_y_croc = 22;
            break;

        case 7:
            *pos_y_croc = 24;
            break;

        case 8:
            *pos_y_croc = 26;
            break;

        case 9:
            *pos_y_croc = 28;
            break;

        case 10:
            *pos_y_croc = 30;
            break;

        case 11:
            *pos_y_croc = 32;
            break;

        default:
            perror("Errore indice coccodrillo coccodrillo");
            exit(-1);

    }
}

void assegna_gruppo_coccodrillo(int i, int * gruppo_coccodrillo)
{

    if(i >= 0 && i < 12)//SE IL COCCODRILLO FA PARTE DEL PRIMO GRUPPO
    {
        *gruppo_coccodrillo = 0;
    }
    else if(i >= 12 && i < 24)//SE IL COCCODRILLO FA PARTE DEL SECONDO GRUPPO
    {
        //ASSEGNA GRUPPO
        *gruppo_coccodrillo = 1;
    }
    else if(i >= 24 && i < 36)//TERZO GRUPPO
    {
        //ASSEGNA GRUPPO
        *gruppo_coccodrillo = 2;
    }
    else if(i >= 36 && i < 48)//QUARTO GRUPPO
    {
        //ASSEGNA GRUPPO
        *gruppo_coccodrillo = 3;
    }

}

void assegna_corsia_coccodrillo(int i, int * corsia_coccodrillo)
{

    *corsia_coccodrillo = i%NUMCORSIECOCCODRILLI;

}

int rand_range(int min, int max)
{
    int res = 0;

    if (min > max)
    {
        perror("Errore: min non può essere maggiore di max");
        exit(-1);
        return -1; // Errore: min non può essere maggiore di max
    }

    res = rand() % (max - min + 1) + min;

    return res;
}

int assegna_dist(int gruppo_coccodrillo)
{

    int dist = 0;

    if(gruppo_coccodrillo == 0)
    {
        dist = rand_range(5, 10);
    }
    else if(gruppo_coccodrillo == 1)
    {
        dist = rand_range(22, 27);
    }
    else if(gruppo_coccodrillo == 2)
    {
        dist = rand_range(39, 44);
    }
    else if(gruppo_coccodrillo == 3)
    {
        dist = rand_range(56, 61);
    }

    return dist;

}

int processo_coccodrillo(int i, int pipe_controllo[2], float speed)
{

    //srand(time(NULL) + getpid());//USO GETPID PER AVERE UN SEED DIVERSO PER OGNI PROCESSO

    FILE* file = fopen("debug.txt", "a");
    fprintf(file, "speed croc %d:%f", i, speed);
    fclose(file);


    bool loop = true;
    bool verso_destra = false;

    int gruppo_coccodrillo = -1;
    int dist = 0;

    //coordinate di spawn dei coccodrilli
    int spawn_x_s = - 8;//coordinata x sinistra
    //sottraggo la lunghezza del coccodrillo per poterlo stampare interamente
    //altrimenti la scritta va a capo nel lato sinistro
    int spawn_x_d = COLS;//coordinata x destra
    //float per la posizione convertiti in int prima di inviare il messaggio
    float pos_x_croc = 0;
    int pos_y_croc = 0;

    int last_x = -1;
    int last_y = -1;

    int succ = -1;

    messaggio mess_croc;
    mess_croc.indice_o_vite = i;
    mess_croc.pos_x = 0;
    mess_croc.pos_y = 0;
    mess_croc.speed = 0;

    verso_destra = assegna_verso_coccodrillo(i);

    //ASSEGNA IL VALORE DEL VERSO DEL COCCODRILLO AL MESSAGGIO DA INVIARE AL PROCESSO CONTROLLO
    mess_croc.verso_destra_o_apri = verso_destra;

    assegna_spawn_x_coccodrillo(verso_destra, &pos_x_croc, spawn_x_s, spawn_x_d);

    assegna_pos_y_in_base_a_indice_coccodrillo(i, &pos_y_croc);

    assegna_gruppo_coccodrillo(i, &gruppo_coccodrillo);

    dist = assegna_dist(gruppo_coccodrillo);

    if(verso_destra)
    {
        pos_x_croc = spawn_x_s + dist;
    }
    else
    {
        pos_x_croc = spawn_x_d - dist;
    }

    close(pipe_controllo[0]);

    /*
    //SCRIVI NEL FILE DI DEBUG
    FILE * file = fopen("debug.txt", "a");
    fprintf(file, "Coccodrillo %d spawn_x_s: %d spawn_x_d: %d pos_x_croc: %f pos_y_croc: %d\n",
            i, spawn_x_s, spawn_x_d, pos_x_croc, pos_y_croc);*/

    while (loop)
    {

        //RESPAWNA COCCODRILLO SE OLTRE IL BORDO
        if(verso_destra)
        {
            if(pos_x_croc > spawn_x_d)
            {
                pos_x_croc = spawn_x_s;
            }
        }
        else
        {
            if(pos_x_croc < spawn_x_s)
            {
                pos_x_croc = spawn_x_d;
            }
        }

        //MUOVI COCCODRILLO OGNI FRAME
        if(verso_destra)
        {
            pos_x_croc += speed;
        }
        else
        {
            pos_x_croc -= speed;
        }

        //ASSEGNA VALORI AL MESSAGGIO
        mess_croc.pos_x = (int)pos_x_croc;
        mess_croc.pos_y = pos_y_croc;
        mess_croc.speed = speed;
        mess_croc.header = COCCODRILLO;
        mess_croc.indice_o_vite = i;

        //INVIA LA POSIZIONE DEI COCCODRILLI
        //AL CONTROLLO

        //SE LA POSIZIONE DEL COCCODRILLO è STATA CAMBIATA
        //EFFETTUO QUESTO CONTROLLO PER NON INTASARE LA PIPE
        while(last_x != (int)pos_x_croc)
        {
            succ = write(pipe_controllo[1], &mess_croc, sizeof(messaggio));
            if(succ == -1)
            {
                file = fopen("debug.txt", "a");
                fprintf(file, "\nErrore scrittura messaggio coccodrillo:");
                fclose(file);
                exit(-1);                        
            }

            last_x = (int)pos_x_croc;
            last_y = (int)pos_y_croc;
        }
              

             
        

        

        napms(25);
    }


    return 0;
}
