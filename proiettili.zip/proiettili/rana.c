#include <unistd.h>
#include <ncurses.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>

#include "rana.h"
#include "croc.h"
#include "messaggi.h"

// Funzione per disegnare la rana sullo schermo
// `pos_x` e `pos_y` rappresentano le coordinate della rana
int disegna_rana(int pos_x, int pos_y)
{
    mvprintw(pos_y, pos_x - 2, RANA1); // Disegna la parte superiore della rana
    mvprintw(pos_y + 1, pos_x - 2, RANA2); // Disegna la parte inferiore della rana
    return 0;
}

int disegna_proiettile(int pos_x, int pos_y)
{
    mvaddch(pos_y, pos_x, PROIETTILE); // Disegna il proiettile
    return 0;
}

// Funzione per verificare se c'è una collisione tra la rana e un coccodrillo
// `x_rana` e `y_rana` sono le coordinate della rana
// `x_croc` e `y_croc` sono le coordinate del coccodrillo
bool collisione_rana_coccodrillo(int x_rana, int y_rana, int x_croc, int y_croc)
{
    // Controlla se la rana si trova sulla stessa riga del coccodrillo
    if (y_rana == y_croc)
    {
        // Controlla se la rana si trova sopra il corpo del coccodrillo
        if (x_rana >= x_croc && x_rana <= x_croc + strlen(CROC1D))
        {
            return true; // Collisione rilevata
        }
    }
    return false; // Nessuna collisione
}

// Funzione per verificare se una tana è libera
// `x` è la posizione orizzontale della rana
// `tana_aperte` è un array di booleani che indica lo stato delle tane
bool tana_libera(int x, bool tana_aperte[])
{
    // Controlla se la tana corrispondente alla posizione `x` è aperta
    switch (x)
    {
        case 15: return tana_aperte[0];
        case 27: return tana_aperte[1];
        case 39: return tana_aperte[2];
        case 51: return tana_aperte[3];
        case 63: return tana_aperte[4];
        default: return false; // Nessuna tana corrisponde alla posizione
    }
}

// Funzione per determinare la corsia di un coccodrillo in base alla sua posizione verticale
// `pos_y` è la posizione verticale del coccodrillo
int get_corsia_croc(int pos_y)
{
    int corsia = -1; // Valore di default per indicare un errore

    // Mappa la posizione verticale alla corsia corrispondente
    switch (pos_y)
    {
        case 10: corsia = 0; break;
        case 12: corsia = 1; break;
        case 14: corsia = 2; break;
        case 16: corsia = 3; break;
        case 18: corsia = 4; break;
        case 20: corsia = 5; break;
        case 22: corsia = 6; break;
        case 24: corsia = 7; break;
        case 26: corsia = 8; break;
        case 28: corsia = 9; break;
        case 30: corsia = 10; break;
        case 32: corsia = 11; break;
        default:
            perror("Errore indice coccodrillo"); // Messaggio di errore
            exit(-1); // Termina il programma con un errore
    }

    return corsia; // Restituisce la corsia corrispondente
}


//funzione per creare due processi per i proiettili
// `pos_x` e `pos_y` sono le coordinate della rana 
int crea_proiettile(int pipe_proiettili_rana[2], int pos_x, int pos_y, int pipe_controllo[2], bool verso_destra)
{
    pid_t proiettile = fork(); // Crea un nuovo processo per il proiettile
    if (proiettile == -1)
    {
        perror("Errore fork proiettile dx");
        exit(-1); // Termina il programma in caso di errore
    }
    
    if (proiettile == 0) // Processo figlio per il proiettile destro
    {
        bool loop = true;

        int pos_x_proiettile = 0;
        
        if(verso_destra)
        {
            pos_x_proiettile = pos_x + 1;// Posizione iniziale del proiettile
        } 
        else
        {
            pos_x_proiettile = pos_x - 1;// Posizione iniziale del proiettile
        }

        int pos_y_proiettile = pos_y; // Posizione verticale del proiettile
        messaggio mess_proiettile; // Messaggio per comunicare la posizione del proiettile

        while (loop) // Ciclo finché il proiettile non esce dallo schermo            refresh(); // Aggiorna lo schermo
        {

            if(verso_destra)
            {
                loop = pos_x_proiettile < COLS;
            }
            else
            {
                loop = pos_x_proiettile > -2;
            }

            // Invia la posizione del proiettile al processo di controllo
            mess_proiettile.header = PROIETTILI; // Header per identificare il messaggio
            mess_proiettile.pos_x = pos_x_proiettile;
            mess_proiettile.pos_y = pos_y_proiettile;
            mess_proiettile.verso_destra_o_apri = verso_destra;
            write(pipe_controllo[1], &mess_proiettile, sizeof(messaggio));

            if(verso_destra)
            {
                pos_x_proiettile++; // Muove il proiettile verso destra
            }
            else
            {
                pos_x_proiettile--;
            }
            
            napms(50); // Ritardo per limitare la velocità del proiettile
        }

        mess_granata mess;
        mess.verso_destra = verso_destra;
        mess.proiettile_vivo = false;


        //COMUNICA AL PROCESSO RANA CHE IL PROIETTILE E' MORTO
        write(pipe_proiettili_rana[1], &mess, sizeof(mess_granata));

        exit(0); // Termina il processo del proiettile
    }
}


// Funzione principale del processo che gestisce la rana
// `pipe_controllo` è la pipe per comunicare con il processo di controllo
// `pipe_rana` è la pipe per ricevere messaggi dal processo di controllo
int processo_rana(int pipe_controllo[2], int pipe_rana[2])
{
    char ch; // Variabile per memorizzare l'input da tastiera
    float pos_x_rana = COLS / 2; // Posizione orizzontale iniziale della rana (centrata)
    int pos_y_rana = LINES - 6; // Posizione verticale iniziale della rana (vicino al bordo inferiore)

    int pos_x_croc[NUMCOCCODRILLI], pos_y_croc[NUMCOCCODRILLI]; // Coordinate dei coccodrilli
    int succ = -1; // Variabile per controllare il successo della lettura dalla pipe
    bool loop = true; // Variabile per controllare il ciclo principale
    bool tane_aperte[5] = {true, true, true, true, true}; // Stato delle tane (tutte aperte inizialmente)
    FILE* file = NULL; // Puntatore a file per il debug
    float speed_attuale = -1; // Velocità attuale della rana (non usata qui)
    int corsia_attuale = -1; // Corsia attuale della rana (non usata qui)

    msg_type header = RANA; // Tipo di messaggio per identificare la rana
    messaggio mess_rana; // Struttura per inviare messaggi al processo di controllo
    mess_rana.pos_x = -2; // Inizializza la posizione del messaggio
    mess_rana.pos_y = -2;
    messaggio buffer; // Buffer per messaggi generici
    messaggio_rana mess_controllo; // Struttura per ricevere messaggi dal processo di controllo

    bool puo_sparare = true;//TRUE SE LA RANA PUO SPARARE FALSE SE NON PUO PERCHE CE ANCORA IL PROIETTILE IN GIRO

    bool proiettili_vivi[2];//INDICA SE I PROIETTILI SONO ANCORA IN CIRCOLO O SE IL PROCESSO è MORTO

    for (int i = 0; i < 2; i++)
    {
        proiettili_vivi[i] = false;
    }
    

    int pipe_proiettili_rana[2];

    if(pipe(pipe_proiettili_rana) == -1)
    {
        perror("Errore creazione pipe proiettili-rana");
        exit(0);
    }

    //close(pipe_proiettili_rana[1]);
    fcntl(pipe_proiettili_rana[0], F_SETFL, O_NONBLOCK);

    close(pipe_controllo[0]); // Chiude l'estremità di lettura della pipe di controllo

    while (loop) // Ciclo principale del processo rana
    {
        // Controlla l'input da tastiera
        ch = getch(); // Legge un carattere dalla tastiera
        switch (ch)
        {
            case 'w': // Movimento verso l'alto
                if (pos_y_rana > 7) 
                {
                    pos_y_rana -= SALTO; // Salta verso l'alto
                }
                else if (pos_y_rana == 6) // Se è vicino alla tana
                {
                    if ((int)pos_x_rana == 15 || (int)pos_x_rana == 27 || (int)pos_x_rana == 39 || (int)pos_x_rana == 51 || (int)pos_x_rana == 63)
                    {
                        if (tana_libera((int)pos_x_rana, tane_aperte)) // Controlla se la tana è libera
                        {
                            pos_y_rana -= SALTO; // Salta nella tana
                            int i = (int)(pos_x_rana - 15) / 12; // Calcola l'indice della tana
                            tane_aperte[i] = false; // Chiude la tana

                            // Invia un messaggio al processo di controllo per chiudere la tana
                            messaggio mess_tana;
                            mess_tana.indice_o_vite = i;//indice della tana
                            mess_tana.verso_destra_o_apri = false; // Chiude la tana
                            mess_tana.header = TANA;
                            write(pipe_controllo[1], &mess_tana, sizeof(messaggio));
                        }
                    }
                }
                break;

            case 's': // Movimento verso il basso
                if (pos_y_rana < LINES - 7)
                {
                    pos_y_rana += SALTO; // Muove la rana verso il basso
                }
                break;

            case 'a': // Movimento verso sinistra
                if ((int)pos_x_rana > 3)
                {
                    pos_x_rana -= 1; // Muove la rana verso sinistra
                }
                break;

            case 'd': // Movimento verso destra
                if ((int)pos_x_rana < COLS - 2)
                {
                    pos_x_rana += 1; // Muove la rana verso destra
                }
                break;

            case 'q': // Esci dal gioco
                pos_x_rana = -1;
                pos_y_rana = -1;
                loop = false; // Termina il ciclo
                break;

            case ' ': // Spara proiettili

                int succ = 0;
                mess_granata mess;
                succ = read(pipe_proiettili_rana[0], &mess, sizeof(mess_granata));
                if(mess.verso_destra)
                {
                    proiettili_vivi[0] = mess.proiettile_vivo;
                }
                else
                {
                    proiettili_vivi[1] = mess.proiettile_vivo;
                }

                if(proiettili_vivi[0] == false && proiettili_vivi[1] == false)
                {
                    puo_sparare = true;
                }

                if (pos_y_rana > 9 && pos_y_rana <= 33 && puo_sparare) // Se la rana è in una posizione valida
                {   
                    //TRUE VERSO DESTRA, FALSE A SINISTRA
                    crea_proiettile(pipe_proiettili_rana, pos_x_rana, pos_y_rana, pipe_controllo, true); // Crea i proiettili e comunica la posizione
                    crea_proiettile(pipe_proiettili_rana, pos_x_rana, pos_y_rana, pipe_controllo, false);

                    proiettili_vivi[0] = true;
                    proiettili_vivi[1] = true;

                    puo_sparare = false;
                }
                break;

            default:
                break;
        }

         // Legge eventuali modifiche alla posizione della rana dal processo di controllo
        succ = read(pipe_rana[0], &mess_controllo, sizeof(messaggio_rana));
        if (succ)
        {
            if (mess_controllo.header == CONTROLLO_RANA)
            {
                pos_x_rana = mess_controllo.pos_x; // Aggiorna la posizione orizzontale
                pos_y_rana = mess_controllo.pos_y; // Aggiorna la posizione verticale

                // Scrive la nuova posizione nel file di debug
                file = fopen("debug.txt", "a");
                fprintf(file, "\nNuova posizione rana: x:%d y:%d", (int)pos_x_rana, pos_y_rana);
                fclose(file);
            }
            succ = -1; // Resetta il valore di successo
            //buffer.header = NULLO; // Resetta il buffer
        }


        // Invia la posizione della rana al processo di controllo per la stampa
        mess_rana.pos_x = (int)pos_x_rana;
        mess_rana.pos_y = pos_y_rana;
        mess_rana.header = RANA;
        write(pipe_controllo[1], &mess_rana, sizeof(messaggio));

       
        napms(25); // Introduce un ritardo di 25 ms per limitare la velocità del ciclo
    }

    exit(0); // Termina il processo
}