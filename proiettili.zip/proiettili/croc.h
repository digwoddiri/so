
#ifndef PROGETTOSO_CROC_H
#define PROGETTOSO_CROC_H

#define CROC1S ">====-"
#define CROC1D "-====<"
#define CROC2 " '  ' "

#define NUMCOCCODRILLIPERCORSIA 4
#define NUMCORSIECOCCODRILLI 12
#define NUMCOCCODRILLI NUMCOCCODRILLIPERCORSIA * NUMCORSIECOCCODRILLI//48
#define SPEED 0.1//VELOCITA COCCODRILLI





void tronca_stringa(char *str);
//int stampa_coccodrillo(int pos_x, int pos_y, bool verso_destra, int indice);
int stampa_coccodrillo_mat(int pos_x, int pos_y, bool verso_destrae);
int processo_coccodrillo(int i, int pipe_controllo[2], float speed);
void assegna_gruppo_coccodrillo(int i, int * gruppo_coccodrillo);
void assegna_corsia_coccodrillo(int i, int * corsia_coccodrillo);
int rand_range(int min, int max);
int assegna_dist(int gruppo_coccodrillo);

#endif //PROGETTOSO_CROC_H
