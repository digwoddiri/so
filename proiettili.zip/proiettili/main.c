#include <unistd.h>
#include <ncurses.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h> //libreria per pipe non bloccanti

#include "rana.h"
#include "croc.h"
#include "messaggi.h"

// DEFINIZIONE PER DISEGNO
#define TERRENO '#'
#define LARGHEZA_TANA 5

//ALTRI DEFINE
#define SCREEN_SIZE_X 80
#define SCREEN_SIZE_Y 40

#define QUIT -1

#define RIVA_ALTA_START 6
#define RIVA_ALTA_END 10
#define RIVA_BASSA_START LINES - 6
#define RIVA_BASSA_END LINES - 3
#define ACQUA_START 10
#define ACQUA_END LINES - 6


void svuota_pipe(int pipe_fd[]);
void debug(char * msg);
void debug_int(char * msg, int num);
void debug_float(char * msg, float num);
int processo_controllo(int pipe_rana[2], int pipe_controllo[2], float speed[NUMCORSIECOCCODRILLI]);
void riempi_prime_tre_linee();
int aggiorna_mappa(bool tane_aperte[5], int vite, int time_left);
void riempi_linee_4_5_6_dal_basso();
int stampa_tana(int pos_y, int pos_x, bool tana_aperta);
int stampa_riva_alta();
int stampa_riva_bassa();
void menu();



//definizione processi
pid_t pid_controllo;
pid_t pid_rana;
pid_t pid_croc[NUMCOCCODRILLI];
pid_t pid_timer[NUMCOCCODRILLI * 3];

FILE* file_debug = NULL;





//TODO
/*
    -MESSAGGI AL PLAYER TRAMITE PIPE E PROCESSO CONTROLLO
    -MENU
    -PULIZIA CODICE
    -COMMENTI
    -FILE E MAKEFILE
    -PIU COCCODRILLI E SISTEMAZIONE SPAWN COCCODRILLI
    -PROIETTILI RANA E COCCODRILLI
    -SUONI?
    -SALVATAGGIO?
    -PUNTEGGIO
    -TEMPO
    -1-UP
    -HI-SCORE

*/



int main()
{
    initscr(); // crea schermo
    noecho(); // Disabilita l'eco dell'input
    cbreak(); // Disabilita il buffering della riga
    curs_set(0); // Nasconde il cursore
    nodelay(stdscr, TRUE); // Imposta la modalità non bloccante per l'input

    //PULISCI FILE DEBUG
    file_debug = fopen("debug.txt", "w");
    fclose(file_debug);

    float speed[NUMCORSIECOCCODRILLI];//velocita coccodrilli
    int corsia_coccodrillo = 0;

    if(COLS < SCREEN_SIZE_X || LINES < SCREEN_SIZE_Y)
    {
        //perror("Ingrandisci la finestra!");
        printf("Ingrandisci la finestra!\n");
        endwin();
        exit(-1);
    }

    // Crea una finestra di dimensione fissa
    resize_term(SCREEN_SIZE_Y, SCREEN_SIZE_X);
    refresh();

    //MENU
    menu();

    // definizione pipe
    int pipe_controllo[2];
    int pipe_rana[2];

    //CREAZIONE PIPE
    if(pipe(pipe_controllo) == -1)
    {
        perror("\nErrore creazione pipe");
        endwin();
        return 1;
    }
    if(pipe(pipe_rana) == -1)
    {
        perror("\nErrore creazione pipe");
        endwin();
        return 1;
    }

    // Imposta la pipe in modalità non bloccante
    fcntl(pipe_controllo[0], F_SETFL, O_NONBLOCK);
    fcntl(pipe_rana[0], F_SETFL, O_NONBLOCK);


    //CREA PROCESSI E ASSEGNA FUNZIONI
    pid_controllo = fork();
    if (pid_controllo == -1)
    {
        perror("Errore fork");
        endwin();
        return 1;
    }

    //SE PROCESSO CONTROLLO
    if (pid_controllo == 0)
    {
        
        //DETERMINA LE VELOCITA DEI COCCODRILLI
        for (int i = 0; i < NUMCORSIECOCCODRILLI; ++i)
        {
            speed[i] = (float)rand_range(1, 3);
            speed[i] = speed[i] / 10;
            debug_float("Speed: ", speed[i]);
        }

        //DA FARE DENTRO IL PROCESSO COCCODIRLLO

        pid_rana = fork();
        if(pid_rana == -1)
        {
            perror("Errore fork");
            endwin();
            return -1;
        }

        if(pid_rana == 0)
        {
            debug("Processo rana creato");
            processo_rana(pipe_controllo, pipe_rana);
            //exit(0);
        }

        for (int i = 0; i < NUMCOCCODRILLI; i++)
        {
            pid_croc[i] = fork();

            if (pid_croc[i] == -1)
            {
                perror("Errore fork");
                exit(-1);
            }

            if (pid_croc[i] == 0)
            {
                debug_int("Processo coccodrillo creato, indice: %d", i);
                assegna_corsia_coccodrillo(i, &corsia_coccodrillo);
                //debug_float("Corsia coccodrillo: ", corsia_coccodrillo);
                //debug_float("Speed: ", speed[corsia_coccodrillo]);
                processo_coccodrillo(i, pipe_controllo, speed[i%NUMCORSIECOCCODRILLI]);
                //exit(0);
            }
        }

        debug("Processo controllo creato");
        processo_controllo(pipe_rana, pipe_controllo, speed);

    }


    //close(pipe_controllo[1]);

    wait(NULL);

    endwin();

    debug("Fine debug");

    return 0;
}
void menu()
{
    const char* str = "BENVENUTO IN FROGGER";
    bool ciclo = true;
    char c;
    int selezione = 0;

    while(ciclo)
    {
        c = getch();

        if(c == 'q')
        {
            ciclo = false;
            endwin();
            exit(0);

        }
        if(c == 'w')
        {
            selezione--;
        }
        if(c == 's')
        {
            selezione++;
        }

        //TRE SCELTE
        if(selezione < 0)
        {
            selezione = 2;
        }
        if(selezione > 2)
        {
            selezione = 0;
        }

        //STAMPA MENU
        mvprintw(LINES/2 - 2, (COLS/2 - (strlen(str)/2)), "%s", str);
        switch (selezione)
        {
            case 0:
                mvprintw(LINES/2, (COLS/2 - 5), "-> 1. Gioca");
                mvprintw(LINES/2 + 1, (COLS/2 - 5), "   2. Opzioni");
                mvprintw(LINES/2 + 2, (COLS/2 - 5), "   3. Esci");
                break;

            case 1:
                mvprintw(LINES/2, (COLS/2 - 5), "   1. Gioca");
                mvprintw(LINES/2 + 1, (COLS/2 - 5), "-> 2. Opzioni");
                mvprintw(LINES/2 + 2, (COLS/2 - 5), "   3. Esci");
                break;

            case 2:
                mvprintw(LINES/2, (COLS/2 - 5), "   1. Gioca");
                mvprintw(LINES/2 + 1, (COLS/2 - 5), "   2. Opzioni");
                mvprintw(LINES/2 + 2, (COLS/2 - 5), "-> 3. Esci");
                break;
        }

        if(c == '\n')
        {
            switch (selezione)
            {
                case 0://INIZIA IL GIOCO
                    ciclo = false;
                    break;
                case 1://OPZIONI TO DO
                    break;
                case 2://ESCI DAL GIOCO
                    endwin();
                    exit(0);
                    break;
            }
        }

        refresh();

    }



}
void debug_int(char * msg, int num)
{
    //APRI IN MODALITA APPEND
    file_debug = fopen("debug.txt", "a");
    fprintf(file_debug, "%s %d\n", msg, num);
    fclose(file_debug);
}
void debug_float(char * msg, float num)
{
    //APRI IN MODALITA APPEND
    file_debug = fopen("debug.txt", "a");
    fprintf(file_debug, "%s %f\n", msg, num);
    fclose(file_debug);
}
void debug(char * msg)
{
    //APRI IN MODALITA APPEND
    file_debug = fopen("debug.txt", "a");
    fprintf(file_debug, "%s\n", msg);
    fclose(file_debug);
}
int stampa_tana(int pos_y, int pos_x, bool tana_aperta)
{
    //STAMPA UNA TANA IN pos_x pos_y APERTA O CHIUSA

    int base_tana = 0;

    if(tana_aperta)
    {

        for (int i = 0; i < LARGHEZA_TANA; i++)
        {
            mvaddch(pos_y, pos_x + i, '_');
        }

        for (int i = 1; i < 3; i++)
        {
            mvprintw(pos_y + i, pos_x, "|   |");
        }
    }
    else//tana chiusa
    {
        for (int i = 0; i < LARGHEZA_TANA; i++)
        {
            mvaddch(pos_y, pos_x + i, '_');
        }

        for (int i = 1; i < 2; i++)
        {
            mvprintw(pos_y + i, pos_x, "|   |");
            base_tana = pos_y + i + 1;
        }

        mvprintw(base_tana, pos_x, "|___|");

    }

    return 0;
}
int stampa_riva_alta()
{
    //stampa riva in alto
    for (int y = RIVA_ALTA_START; y < RIVA_ALTA_END; y++)
    {
        for (int x = 0; x < COLS; x++)
        {
            mvaddch(y, x, TERRENO);
        }
    }

    return 0;
}
int stampa_riva_bassa()
{
    //stampa riva in basso
    for (int y = RIVA_BASSA_START; y < RIVA_BASSA_END; y++)
    {
        for (int x = 0; x < COLS; x++)
        {
            mvaddch(y, x, TERRENO);
        }
    }

    return 0;
}
int stampa_acqua()
{
    //STAMPA CARATTERI VUOTI NELLA ZONA DI ACQUA
    for (int y = ACQUA_START; y < ACQUA_END; y++)
    {
        for (int x = 0; x < COLS; x++)
        {
            mvaddch(y, x, VUOTO);
        }
    }

    return 0;
}
int aggiorna_mappa(bool tane_aperte[5], int vite, int time_left)
{
    //tane_aperte -> array di bool che indica se la tana è aperta o chiusa
    //vite -> numero di vite rimanenti


    int dist = 9;
    int offset = 3;

    mvprintw(1, 3, "1-UP:");

    mvprintw(1, COLS - 25, "HI-SCORE:");


    //STAMPA TRATTINI
    for(int i = 0; i < COLS; i++)
    {
        for(int j = 3; j < 6; j++)
        {
            mvaddch(j, i, '~');
        }
    }
    for (int i = 1; i < 6; i++)
    {
        stampa_tana(3, (dist * i) + i * offset, tane_aperte[i - 1]);
    }

    //RIVA IN ALTO
    stampa_riva_alta();

    //RIVA IN BASSO
    stampa_riva_bassa();

    stampa_acqua();

    //VITE
    mvprintw(LINES - 2, 3, "VITE:%d", vite);

    //TEMPO
    mvprintw(LINES - 2, COLS - 15, "                                    ");

    mvprintw(LINES - 2, COLS - 15, "TIME LEFT:%d", time_left);

    
    //refresh();

    return 0;
}

int processo_controllo(int pipe_rana[2], int pipe_controllo[2], float speed[NUMCORSIECOCCODRILLI])
{
    //RANA
    int vite = 5;//VITE RANA

    int pos_x_rana = -2;
    float counter_movimento = 0;
    int pos_y_rana = -2;
    bool puo_inviare_messaggio = true;


    int pos_x_proiettile_sx = -1;
    int pos_y_proiettile_sx = -1; 
    int pos_x_proiettile_dx = -1;
    int pos_y_proiettile_dx = -1;  
    
    //COCCODRILLI
    int pos_x_croc[NUMCOCCODRILLI];
    int pos_y_croc[NUMCOCCODRILLI];
    bool verso_destra[NUMCOCCODRILLI];
    int indice = -1;

    int corsia_attuale = -1;
    int speed_attuale = 0;


    //INIZIALIZZA POS COCCODRILLI
    for (int i = 0; i < NUMCOCCODRILLI; i++)
    {
        pos_x_croc[i] = -1;
        pos_y_croc[i] = -1;
    }
    

    //VARIABILE PER IL CICLO
    bool loop = true;
    bool lettura = true;
    bool da_respawnare = false;
    bool ritarda_lettura_rana = false;
    

    //CONTROLLO LETTURA
    int succ = -1;

    //ARRAY TANE APERTE
    bool tane_aperte[5] = {true, true, true, true, true};

    //STRUTTURA MESSAGGIO TANA
    //messaggio_tana mess_tana;

    int numero_cicli_effettuati = 0;
    int time_max = 100;
    int tempo_rimanente = 0;

    //STRUTTURA MESSAGGIO COCCODRILLO
    messaggio mess;
    messaggio_rana mess_rana;

    FILE* file = NULL;

    //CHIUDI PIPE IN SCITTURA
    close(pipe_controllo[1]);

    while(loop)
    {
        lettura = true;
        while(lettura)
        {
            //debug("Tentativo lettura");
            //LEGGI DATI 
            succ = read(pipe_controllo[0], &mess, sizeof(messaggio));//LEGGI UN MESSAGGIO GENERALE
            if(succ > 0)
            {
                switch (mess.header)
                {
                    case RANA://LEGGI MESSAGGIO RANA

                        //file = fopen("debug.txt", "a");
                        //fprintf(file, "\nRANA: pos lette x:%d y:%d", mess.pos_x, mess.pos_y);
                        //fclose(file);

                        //LEGGI LA POSIZIONE DELLA RANA
                        pos_x_rana = mess.pos_x;
                        pos_y_rana = mess.pos_y;

                        if(pos_x_rana == QUIT && pos_y_rana == QUIT)
                        {
                            lettura = false;
                            loop = false;
                        }

                        break;

                    case COCCODRILLO://LEGGI MESSAGGIO COCCODRILLO

                        //file = fopen("debug.txt", "a");
                        //fprintf(file, "\nRANA: pos lette x:%d y:%d", mess.pos_x, mess.pos_y);
                        //fclose(file);

                        pos_x_croc[mess.indice_o_vite] = mess.pos_x;
                        pos_y_croc[mess.indice_o_vite] = mess.pos_y;
                        verso_destra[mess.indice_o_vite] = mess.verso_destra_o_apri;

                        break;
                    
                    case TANA:
                        
                        tane_aperte[mess.indice_o_vite] = mess.verso_destra_o_apri;
                        break;

                    case PROIETTILI: // Gestisce il messaggio dei proiettili
                        
                        if(mess.verso_destra_o_apri)
                        {
                            //VERSO DESTRA
                            pos_x_proiettile_dx = mess.pos_x;
                            pos_y_proiettile_dx = mess.pos_y;
                        }
                        else
                        {
                            //VERSO SINISTRA
                            pos_x_proiettile_sx = mess.pos_x;
                            pos_y_proiettile_sx = mess.pos_y;
                        }
                        
                        break;
                    
                    default:
                        debug_int("\nHeader non riconosciuto ERRORE", mess.header);
                        //lettura = false;
                        exit(-1);
                        break;
                }

            }
            else
            {
                lettura = false;//CONTINUA A LEGGERE FINCHE NON CI SONO PIU MESSAGGI DA LEGGERE
                debug("Pipe vuota");
                //napms(25);
            }
            
        }

        //TRA LE VARIABILI DELLA POSIZIONE DELLA RANA DOVREBBE COMANDARE QUELLA NEL PROCESSO RANA
        //IL PROCESSO CONTROLLO STAMPA 

        // Controllo se la rana si trova sopra un coccodrillo
        if (pos_y_rana <= 33 && pos_y_rana > 9) // La rana si trova nella zona dell'acqua
        {
            da_respawnare = true;

            for (int i = 0; i < NUMCOCCODRILLI; ++i)
            {
                // Controlla se la rana è sopra un coccodrillo
                if (pos_y_rana == pos_y_croc[i] && pos_x_rana >= pos_x_croc[i] && pos_x_rana < pos_x_croc[i] + 6) 
                {

                    da_respawnare = false;

                    // Muovi la rana insieme al coccodrillo
                    if (verso_destra[i])
                    {
                        //pos_x_rana++; // Muovi la rana a destra
                    }
                    else
                    {
                        //pos_x_rana--; // Muovi la rana a sinistra
                    }

                    

                    break; // Esci dal ciclo una volta trovato il coccodrillo
                }

            }
        }

        // Controlla se la rana esce dallo schermo
        if (pos_x_rana < 0 || pos_x_rana >= COLS)
        {
            da_respawnare = true; // La rana deve essere respawnata
        }

        //AGGIORNA MAPPA
        aggiorna_mappa(tane_aperte, vite, tempo_rimanente);

        //DISEGNA CROC
        for (int i = 0; i < NUMCOCCODRILLI; i++)
        {
            stampa_coccodrillo_mat(pos_x_croc[i], pos_y_croc[i], verso_destra[i]);
        }
        
        //FILE* file = fopen("debug.txt", "a");
        //fprintf(file, "\nRANA: pos prima della stampa x:%d y:%d", pos_x_rana, pos_y_rana);
        //fclose(file);

        //DISEGNA RANA
        disegna_rana(pos_x_rana, pos_y_rana);

        disegna_proiettile(pos_x_proiettile_sx, pos_y_proiettile_sx);
        disegna_proiettile(pos_x_proiettile_dx, pos_y_proiettile_dx);
        
        //DEBUG
        mvprintw(10, 10, "pos_x_cont:%d", pos_x_rana);
        mvprintw(11, 10, "pos_y_cont:%d", pos_y_rana);
        mvprintw(12, 10, "da_respawnare:%d", da_respawnare);


        refresh();

        napms(25);

    }

    return 0;
}



