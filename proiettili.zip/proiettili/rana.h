

#ifndef PROGETTOSO_RANA_H
#define PROGETTOSO_RANA_H

#define RANA1 "@_@"
#define RANA2 "(_)"
#define VUOTO ' '

#define MAXPROIETTILI 5

#define PROIETTILE 'o'

#define SALTO 2
#define VITE 5

#define NUMCORSIECOCCODRILLI 12

//#include "messaggi.h"




int processo_rana(int pipe_controllo[2], int pipe_rana[2]);
int disegna_rana(int pos_x, int pos_y);
bool collisione_rana_coccodrillo(int x_rana, int y_rana, int x_croc, int y_croc);
int get_input(int *dir_y, int *dir_x);
bool tana_libera(int x, bool tana_aperte[]);
int apri_tana(bool * tana_aperta[5], int i);
int chiudi_tana(bool * tana_aperta[5], int i);
int get_corsia_croc(int pos_y);
int disegna_proiettile(int pos_x, int pos_y);
//int crea_proiettile(int pos_x, int pos_y, int pipe_controllo[2], bool verso_destra)




#endif //PROGETTOSO_RANA_H
