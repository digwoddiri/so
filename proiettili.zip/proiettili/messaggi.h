//
// Created by FRANCESCO on 18/03/2025.
//

#ifndef RANA_SI_MUPVE_CON_COCCODRILLO_MESSAGGI_H
#define RANA_SI_MUPVE_CON_COCCODRILLO_MESSAGGI_H

typedef enum msg_type
{
    TANA = 0,
    COCCODRILLO = 1,
    RANA = 2,
    TIMER = 3,
    CONTROLLO_RANA = 4, 
    NULLO = 5,
    PROIETTILI = 6,
} msg_type;

typedef struct mess_granata
{
    bool verso_destra;
    bool proiettile_vivo;
} mess_granata;

typedef struct messaggio
{
    int header;
    int pos_x;
    int pos_y;
    bool verso_destra_o_apri;
    float speed;
    int indice_o_vite;
    
    
} messaggio;

typedef struct messaggio_rana
{
    int header;
    int pos_x;
    int pos_y;
    int vite;

} messaggio_rana;

#endif //RANA_SI_MUPVE_CON_COCCODRILLO_MESSAGGI_H